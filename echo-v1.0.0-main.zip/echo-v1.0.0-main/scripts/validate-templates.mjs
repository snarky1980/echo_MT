#!/usr/bin/env node
// Removed by revert. This script is disabled.
console.error('[validate-templates] This tool has been removed. No action taken.')
process.exit(1)
